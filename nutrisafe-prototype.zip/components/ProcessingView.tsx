import React, { useEffect, useState } from 'react';
import { Database, Activity, CheckCircle2, Loader2, FlaskConical } from 'lucide-react';

export const ProcessingView: React.FC = () => {
  const [step, setStep] = useState(0);

  const steps = [
    { icon: Activity, text: "Analyzing Medical Profile & Safety Constraints...", color: "text-red-500" },
    { icon: FlaskConical, text: "Querying Foodoscope FlavorDB for Molecular Pairings...", color: "text-purple-500" },
    { icon: Database, text: "Filtering Foodoscope RecipeDB for Safe Matches...", color: "text-blue-500" },
    { icon: CheckCircle2, text: "Finalizing Recommendations...", color: "text-emerald-500" }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setStep((prev) => (prev < steps.length - 1 ? prev + 1 : prev));
    }, 2000); // Simulate 2 seconds per step roughly
    return () => clearInterval(interval);
  }, [steps.length]);

  return (
    <div className="flex flex-col items-center justify-center min-h-[50vh] space-y-8 p-8 w-full max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold text-slate-800">Processing NutriSafe Protocol</h2>
      
      <div className="w-full space-y-4">
        {steps.map((s, index) => {
          const Icon = s.icon;
          const isActive = index === step;
          const isCompleted = index < step;
          const isPending = index > step;

          return (
            <div 
              key={index}
              className={`flex items-center p-4 rounded-lg border transition-all duration-500 ${
                isActive ? 'border-indigo-500 bg-indigo-50 shadow-md scale-105' : 
                isCompleted ? 'border-slate-200 bg-slate-50 opacity-70' : 
                'border-transparent opacity-40'
              }`}
            >
              <div className={`mr-4 ${isActive || isCompleted ? s.color : 'text-slate-400'}`}>
                {isActive ? <Loader2 className="animate-spin h-6 w-6" /> : <Icon className="h-6 w-6" />}
              </div>
              <span className={`font-medium ${isActive ? 'text-slate-900' : 'text-slate-500'}`}>
                {s.text}
              </span>
              {isCompleted && <CheckCircle2 className="ml-auto text-emerald-500 h-5 w-5" />}
            </div>
          );
        })}
      </div>
      
      <p className="text-sm text-slate-400 italic mt-8">
        Connecting to distributed nutrition knowledge graphs...
      </p>
    </div>
  );
};