import React from 'react';
import { AnalysisResult, Recipe } from '../types';
import { Check, AlertTriangle, FlaskConical, ChefHat, ArrowRight } from 'lucide-react';

interface RecipeSelectionProps {
  data: AnalysisResult;
  onSelectRecipe: (recipe: Recipe) => void;
  onBack: () => void;
}

export const RecipeSelection: React.FC<RecipeSelectionProps> = ({ data, onSelectRecipe, onBack }) => {
  return (
    <div className="space-y-8 animate-fade-in pb-12">
      {/* Analysis Summary Section */}
      <div className="grid md:grid-cols-2 gap-6">
        
        {/* Medical Analysis Card */}
        <div className="bg-white p-6 rounded-xl shadow-md border-l-4 border-red-500">
          <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2 mb-4">
            <AlertTriangle className="h-5 w-5 text-red-500" />
            Safety Analysis
          </h3>
          <div className="space-y-3">
            <div>
              <span className="text-xs font-semibold uppercase text-slate-500 tracking-wider">Strictly Avoid</span>
              <div className="flex flex-wrap gap-2 mt-1">
                {data.analysis.avoid.length > 0 ? (
                  data.analysis.avoid.map((item, i) => (
                    <span key={i} className="bg-red-50 text-red-700 px-2 py-1 rounded-md text-sm border border-red-100">
                      {item}
                    </span>
                  ))
                ) : <span className="text-slate-500 text-sm">None identified</span>}
              </div>
            </div>
            <div>
              <span className="text-xs font-semibold uppercase text-slate-500 tracking-wider">Nutritionally Preferred</span>
              <div className="flex flex-wrap gap-2 mt-1">
                {data.analysis.preferred.map((item, i) => (
                  <span key={i} className="bg-emerald-50 text-emerald-700 px-2 py-1 rounded-md text-sm border border-emerald-100">
                    {item}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* FlavorDB Logic Card */}
        <div className="bg-white p-6 rounded-xl shadow-md border-l-4 border-purple-500">
          <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2 mb-4">
            <FlaskConical className="h-5 w-5 text-purple-500" />
            FlavorDB Ingredient Expansion
          </h3>
          <p className="text-sm text-slate-600 mb-3">{data.flavorDB.expansionReasoning}</p>
          <div className="space-y-2 max-h-40 overflow-y-auto pr-2 custom-scrollbar">
            {data.flavorDB.suggestions.map((s, i) => (
              <div key={i} className="text-sm bg-purple-50 p-2 rounded border border-purple-100">
                <div className="flex justify-between font-medium text-purple-900">
                  <span>{s.base}</span>
                  <ArrowRight className="h-4 w-4 text-purple-400 mx-1" />
                  <span>{s.suggestion}</span>
                </div>
                <p className="text-xs text-purple-600 mt-1 italic">"{s.reason}"</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="border-t border-slate-200 my-6"></div>

      {/* Recipe List */}
      <div>
        <h2 className="text-2xl font-bold text-slate-800 mb-6 flex items-center gap-2">
          <ChefHat className="h-6 w-6 text-emerald-600" />
          Recommended Recipes (Foodoscope RecipeDB)
        </h2>
        <div className="grid md:grid-cols-3 gap-6">
          {data.recipes.map((recipe, index) => (
            <div 
              key={recipe.id}
              onClick={() => onSelectRecipe(recipe)}
              className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden hover:shadow-xl hover:border-emerald-400 transition-all cursor-pointer group flex flex-col h-full"
            >
              <div className="h-2 bg-emerald-500 group-hover:bg-emerald-400 transition-colors"></div>
              <div className="p-6 flex-1 flex flex-col">
                <div className="flex items-center justify-between mb-4">
                  <span className="bg-slate-100 text-slate-600 text-xs font-bold px-2 py-1 rounded">#{index + 1}</span>
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-2 group-hover:text-emerald-700 transition-colors">
                  {recipe.name}
                </h3>
                <p className="text-emerald-600 text-sm font-medium mb-4 flex items-center gap-1">
                  <Check className="h-4 w-4" />
                  {recipe.primaryBenefit}
                </p>
                <div className="mt-auto">
                   <p className="text-xs text-slate-500 font-semibold uppercase mb-2">Key Ingredients</p>
                   <div className="flex flex-wrap gap-1">
                     {recipe.keyIngredients.slice(0, 4).map((ing, i) => (
                       <span key={i} className="text-xs bg-slate-50 text-slate-600 px-2 py-1 rounded border border-slate-100">
                         {ing}
                       </span>
                     ))}
                     {recipe.keyIngredients.length > 4 && (
                       <span className="text-xs text-slate-400 px-1 self-center">...</span>
                     )}
                   </div>
                </div>
              </div>
              <div className="bg-slate-50 p-3 text-center text-sm font-medium text-slate-600 group-hover:bg-emerald-50 group-hover:text-emerald-700 transition-colors border-t border-slate-100">
                View Recipe Details
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <button 
        onClick={onBack}
        className="text-slate-500 hover:text-slate-800 font-medium text-sm flex items-center gap-2 mt-4"
      >
        ← Start Over
      </button>
    </div>
  );
};