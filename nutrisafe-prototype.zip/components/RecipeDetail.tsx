import React from 'react';
import { Recipe } from '../types';
import { Clock, Info, ChevronLeft, ShieldCheck, Flame, Target } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

interface RecipeDetailProps {
  recipe: Recipe;
  onBack: () => void;
  dailyGoals?: {
    calories: number;
    protein: number;
    carbs: number;
    fats: number;
  };
}

export const RecipeDetail: React.FC<RecipeDetailProps> = ({ recipe, onBack, dailyGoals }) => {
  const { details } = recipe;

  // Prepare data for the macro chart
  const macroData = [
    { name: 'Protein', value: parseFloat(details.nutrition.protein) || 0, color: '#10b981' }, // emerald-500
    { name: 'Carbs', value: parseFloat(details.nutrition.carbs) || 0, color: '#3b82f6' },   // blue-500
    { name: 'Fats', value: parseFloat(details.nutrition.fats) || 0, color: '#f59e0b' },    // amber-500
  ];

  // Helper for parsing "20g" to 20
  const parseValue = (val: string) => parseFloat(val) || 0;

  const renderProgressBar = (label: string, value: number, goal: number, colorClass: string) => {
    const percentage = Math.min(100, (value / goal) * 100);
    return (
      <div className="mb-4">
        <div className="flex justify-between text-xs mb-1">
          <span className="font-semibold text-slate-600">{label}</span>
          <span className="text-slate-500">{value} / {goal} {label === 'Calories' ? 'kcal' : 'g'}</span>
        </div>
        <div className="w-full bg-slate-200 rounded-full h-2">
          <div 
            className={`h-2 rounded-full transition-all duration-1000 ${colorClass}`} 
            style={{ width: `${percentage}%` }}
          ></div>
        </div>
        <p className="text-[10px] text-right text-slate-400 mt-0.5">{percentage.toFixed(0)}% of daily goal</p>
      </div>
    );
  };

  return (
    <div className="animate-fade-in max-w-4xl mx-auto pb-12">
      <button 
        onClick={onBack} 
        className="flex items-center text-slate-500 hover:text-slate-800 mb-6 font-medium transition-colors"
      >
        <ChevronLeft className="h-5 w-5 mr-1" />
        Back to Recommendations
      </button>

      <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200">
        
        {/* Header */}
        <div className="bg-slate-900 text-white p-8">
          <h1 className="text-3xl font-bold mb-2">{recipe.name}</h1>
          <p className="text-slate-300 flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-emerald-400" />
            NutriSafe Verified: {recipe.primaryBenefit}
          </p>
        </div>

        <div className="grid md:grid-cols-3">
          
          {/* Sidebar: Nutrition & Stats */}
          <div className="md:col-span-1 bg-slate-50 p-6 border-r border-slate-200">
            <div className="mb-8">
              <h3 className="text-sm font-bold uppercase text-slate-500 tracking-wider mb-4 flex items-center gap-2">
                <Flame className="h-4 w-4" /> Nutrition Profile
              </h3>
              
              <div className="h-48 w-full relative">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={macroData}
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={60}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {macroData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex items-center justify-center flex-col pointer-events-none">
                   <span className="text-lg font-bold text-slate-800">{details.nutrition.calories}</span>
                   <span className="text-xs text-slate-500">kcal</span>
                </div>
              </div>

              {dailyGoals ? (
                <div className="mt-6">
                  <h4 className="text-xs font-bold text-slate-500 uppercase mb-3 flex items-center gap-1">
                    <Target className="h-3 w-3" /> Daily Contribution
                  </h4>
                  {renderProgressBar("Calories", details.nutrition.calories, dailyGoals.calories, "bg-slate-700")}
                  {renderProgressBar("Protein", parseValue(details.nutrition.protein), dailyGoals.protein, "bg-emerald-500")}
                  {renderProgressBar("Carbs", parseValue(details.nutrition.carbs), dailyGoals.carbs, "bg-blue-500")}
                  {renderProgressBar("Fats", parseValue(details.nutrition.fats), dailyGoals.fats, "bg-amber-500")}
                </div>
              ) : (
                <div className="space-y-3 mt-4 text-sm">
                  <div className="flex justify-between">
                    <span className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-emerald-500"></div> Protein
                    </span>
                    <span className="font-semibold">{details.nutrition.protein}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-blue-500"></div> Carbs
                    </span>
                    <span className="font-semibold">{details.nutrition.carbs}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-amber-500"></div> Fats
                    </span>
                    <span className="font-semibold">{details.nutrition.fats}</span>
                  </div>
                </div>
              )}
              
              <div className="mt-6 pt-6 border-t border-slate-200">
                 <h4 className="text-xs font-bold text-slate-500 uppercase mb-2">Micronutrients</h4>
                 <p className="text-sm text-slate-600 leading-relaxed">{details.nutrition.micros}</p>
              </div>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
              <h3 className="text-sm font-bold text-blue-800 flex items-center gap-2 mb-2">
                <Info className="h-4 w-4" /> Why it's safe
              </h3>
              <p className="text-xs text-blue-700 leading-relaxed">
                {details.safetyReasoning}
              </p>
            </div>
          </div>

          {/* Main Content: Ingredients & Steps */}
          <div className="md:col-span-2 p-8">
            <div className="mb-8">
              <h3 className="text-xl font-bold text-slate-800 mb-4 border-b border-slate-100 pb-2">Ingredients</h3>
              <ul className="grid sm:grid-cols-2 gap-3">
                {details.ingredients.map((ing, i) => (
                  <li key={i} className="flex justify-between text-sm py-2 px-3 bg-slate-50 rounded border border-slate-100">
                    <span className="font-medium text-slate-700">{ing.name}</span>
                    <span className="text-slate-500">{ing.quantity}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="text-xl font-bold text-slate-800 mb-4 border-b border-slate-100 pb-2 flex items-center gap-2">
                <Clock className="h-5 w-5 text-slate-400" />
                Cooking Instructions
              </h3>
              <div className="space-y-6">
                {details.steps.map((step, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-slate-100 text-slate-600 rounded-full flex items-center justify-center font-bold text-sm border border-slate-200">
                      {i + 1}
                    </div>
                    <p className="text-slate-600 leading-relaxed pt-1">
                      {step}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};