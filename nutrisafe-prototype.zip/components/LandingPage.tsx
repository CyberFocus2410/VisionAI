import React from 'react';
import { GoalCategory } from '../types';
import { Activity, TrendingDown, TrendingUp, Search, ArrowRight, ShieldCheck, Utensils } from 'lucide-react';

interface LandingPageProps {
  onSelectGoal: (goal: GoalCategory) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onSelectGoal }) => {
  const features = [
    {
      id: 'disease' as GoalCategory,
      title: 'Disease Based Diet',
      description: 'Medical nutrition therapy tailored to specific health conditions.',
      icon: Activity,
      color: 'bg-red-50 text-red-600',
      border: 'hover:border-red-200',
      shadow: 'hover:shadow-red-100'
    },
    {
      id: 'weight-loss' as GoalCategory,
      title: 'Weight Loss',
      description: 'Calorie-deficit & high-fiber plans to shed pounds safely.',
      icon: TrendingDown,
      color: 'bg-emerald-50 text-emerald-600',
      border: 'hover:border-emerald-200',
      shadow: 'hover:shadow-emerald-100'
    },
    {
      id: 'weight-gain' as GoalCategory,
      title: 'Weight Gain',
      description: 'High-protein & surplus nutrition for building healthy mass.',
      icon: TrendingUp,
      color: 'bg-blue-50 text-blue-600',
      border: 'hover:border-blue-200',
      shadow: 'hover:shadow-blue-100'
    },
    {
      id: 'recipe-discovery' as GoalCategory,
      title: 'Recipe Discovery',
      description: 'Find recipes based on ingredients you already have.',
      icon: Search,
      color: 'bg-amber-50 text-amber-600',
      border: 'hover:border-amber-200',
      shadow: 'hover:shadow-amber-100'
    }
  ];

  return (
    <div className="animate-fade-in space-y-12 py-8">
      <div className="text-center space-y-6 max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-500 uppercase tracking-wide">
          <ShieldCheck className="h-3 w-3" />
          AI-Powered Medical Nutrition
        </div>
        <h1 className="text-5xl font-extrabold text-slate-800 tracking-tight leading-tight">
          Smart Nutrition for a <br/>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-500">
            Healthier You
          </span>
        </h1>
        <p className="text-lg text-slate-500 max-w-2xl mx-auto leading-relaxed">
          NutriSafe combines medical guidelines with <span className="font-semibold text-purple-600">FlavorDB</span> food science to recommend meals that are safe, delicious, and aligned with your goals.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto px-4">
        {features.map((feature) => {
          const Icon = feature.icon;
          return (
            <button
              key={feature.id}
              onClick={() => onSelectGoal(feature.id)}
              className={`relative group bg-white p-8 rounded-2xl shadow-sm border border-slate-100 text-left transition-all duration-300 hover:-translate-y-1 hover:shadow-xl ${feature.border} ${feature.shadow}`}
            >
              <div className={`w-14 h-14 rounded-xl flex items-center justify-center mb-6 transition-colors ${feature.color}`}>
                <Icon className="h-7 w-7" />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-3 group-hover:text-slate-900">
                {feature.title}
              </h3>
              <p className="text-slate-500 leading-relaxed mb-6 pr-8">
                {feature.description}
              </p>
              <div className="flex items-center text-sm font-semibold text-slate-400 group-hover:text-slate-800 transition-colors">
                Start Assessment <ArrowRight className="h-4 w-4 ml-2 transition-transform group-hover:translate-x-1" />
              </div>
            </button>
          );
        })}
      </div>

      <div className="text-center pt-8">
        <p className="text-sm text-slate-400">
          Select a path above to begin your personalized assessment.
        </p>
      </div>
    </div>
  );
};