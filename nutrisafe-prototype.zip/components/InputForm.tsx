import React, { useEffect, useState } from 'react';
import { UserProfile, GoalCategory } from '../types';
import { Activity, Utensils, AlertCircle, Leaf, Droplets, Target, Shield, ArrowRight } from 'lucide-react';

interface InputFormProps {
  initialGoal: GoalCategory;
  onSubmit: (profile: UserProfile) => void;
  onBack: () => void;
}

export const InputForm: React.FC<InputFormProps> = ({ initialGoal, onSubmit, onBack }) => {
  const [profile, setProfile] = useState<UserProfile>({
    primaryGoal: initialGoal,
    conditions: '',
    diet: 'Veg',
    oilLevel: 'Medium',
    allergies: '',
    nutrientFocus: '',
    availableIngredients: '',
    dailyGoals: {
      calories: 2000,
      protein: 60,
      carbs: 250,
      fats: 70
    }
  });

  // Pre-fill logic based on selected goal
  useEffect(() => {
    let newFocus = '';
    let newGoals = { ...profile.dailyGoals };

    switch (initialGoal) {
      case 'weight-loss':
        newFocus = 'Low Calorie, High Fiber, Satiety';
        newGoals = { calories: 1500, protein: 90, carbs: 150, fats: 50 };
        break;
      case 'weight-gain':
        newFocus = 'High Protein, Caloric Surplus, Complex Carbs';
        newGoals = { calories: 2800, protein: 140, carbs: 350, fats: 90 };
        break;
      case 'disease':
        newFocus = 'Balanced, Low Sodium, Anti-inflammatory';
        break;
      case 'recipe-discovery':
        newFocus = 'Balanced Diet';
        break;
    }

    setProfile(p => ({
      ...p,
      primaryGoal: initialGoal,
      nutrientFocus: newFocus,
      dailyGoals: newGoals,
      // Clear conditions if not disease focused to avoid confusion, but user can add
      conditions: initialGoal === 'disease' ? '' : 'General Health Maintenance' 
    }));
  }, [initialGoal]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(profile);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };

  const handleGoalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setProfile({
      ...profile,
      dailyGoals: { ...profile.dailyGoals, [e.target.name]: Number(e.target.value) }
    });
  };

  const getTitle = () => {
    switch (initialGoal) {
      case 'disease': return 'Disease Management Profile';
      case 'weight-loss': return 'Weight Loss Assessment';
      case 'weight-gain': return 'Weight Gain Parameters';
      case 'recipe-discovery': return 'Kitchen Inventory & Preferences';
      default: return 'NutriSafe Assessment';
    }
  };

  return (
    <div className="max-w-4xl mx-auto font-sans animate-fade-in-up">
      <button onClick={onBack} className="mb-6 text-sm font-semibold text-slate-500 hover:text-emerald-600 flex items-center transition-colors">
        <ArrowRight className="h-4 w-4 mr-1 rotate-180" /> Back to Options
      </button>

      <div className="bg-white rounded-3xl shadow-xl shadow-slate-200/60 overflow-hidden border border-slate-100">
        <div className="px-8 py-6 border-b border-slate-50 flex items-center justify-between bg-white">
          <div>
            <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-3">
              <Activity className="h-6 w-6 text-emerald-500" />
              {getTitle()}
            </h2>
            <p className="text-slate-400 text-sm mt-1">
              Customize your nutritional parameters for optimal AI analysis.
            </p>
          </div>
          <div className="hidden md:block px-3 py-1 bg-slate-50 rounded-full text-xs font-bold text-slate-400 border border-slate-100 uppercase tracking-wide">
            Step 2 of 3
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-10">
          
          {/* Section 1: Health & Diet */}
          <div className="grid md:grid-cols-12 gap-8">
            <div className="md:col-span-4">
              <h3 className="text-lg font-bold text-slate-800 mb-2">Medical & Diet</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Your health context determines safety constraints and ingredient filtering.
              </p>
            </div>
            
            <div className="md:col-span-8 space-y-6">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  Health Conditions / Diseases
                </label>
                <input
                  type="text"
                  name="conditions"
                  required
                  placeholder="e.g., Type 2 Diabetes, Hypertension, PCOS"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 placeholder:text-slate-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all shadow-sm"
                  value={profile.conditions}
                  onChange={handleChange}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2 flex items-center gap-2">
                    <Utensils className="h-4 w-4 text-emerald-500" />
                    Diet Type
                  </label>
                  <select
                    name="diet"
                    value={profile.diet}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all appearance-none cursor-pointer shadow-sm"
                  >
                    <option value="Veg">Veg</option>
                    <option value="Non-Veg">Non-Veg</option>
                    <option value="Eggetarian">Eggetarian</option>
                  </select>
                </div>

                <div>
                   <label className="block text-sm font-semibold text-slate-700 mb-2 flex items-center gap-2">
                    <Leaf className="h-4 w-4 text-green-500" />
                    Nutrient Focus
                  </label>
                  <input
                    type="text"
                    name="nutrientFocus"
                    required
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 placeholder:text-slate-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all shadow-sm"
                    value={profile.nutrientFocus}
                    onChange={handleChange}
                  />
                </div>
              </div>

               <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2 flex items-center gap-2">
                  <Droplets className="h-4 w-4 text-amber-500" />
                  Oil Preference
                </label>
                <div className="flex bg-slate-50 rounded-xl p-1.5 border border-slate-100">
                  {['Low-Oily', 'Medium', 'High-Oily'].map((level) => (
                    <button
                      key={level}
                      type="button"
                      onClick={() => setProfile({ ...profile, oilLevel: level as any })}
                      className={`flex-1 py-2.5 text-xs font-bold uppercase tracking-wide rounded-lg transition-all duration-300 ${
                        profile.oilLevel === level
                          ? 'bg-white text-slate-800 shadow-md ring-1 ring-slate-200/50 transform scale-[1.02]'
                          : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {level.replace('-Oily', '')}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2 flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-red-400" />
                  Allergies / Restrictions
                </label>
                <input
                  type="text"
                  name="allergies"
                  placeholder="e.g., Peanuts, Gluten, Shellfish"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 placeholder:text-slate-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all shadow-sm"
                  value={profile.allergies}
                  onChange={handleChange}
                />
              </div>
            </div>
          </div>

          <div className="border-t border-slate-100"></div>

          {/* Section 2: Goals & Inventory */}
          <div className="grid md:grid-cols-12 gap-8">
             <div className="md:col-span-4">
              <h3 className="text-lg font-bold text-slate-800 mb-2">Goals & Inventory</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Set your daily nutritional targets and tell us what ingredients you have.
              </p>
            </div>

            <div className="md:col-span-8 space-y-6">
              <div className="bg-slate-50/50 p-6 rounded-2xl border border-slate-100">
                <label className="block text-sm font-bold text-slate-700 mb-4 flex items-center gap-2">
                  <Target className="h-4 w-4 text-blue-500" /> Daily Targets
                </label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { name: 'calories', label: 'Calories', unit: 'kcal' },
                    { name: 'protein', label: 'Protein', unit: 'g' },
                    { name: 'carbs', label: 'Carbs', unit: 'g' },
                    { name: 'fats', label: 'Fats', unit: 'g' },
                  ].map((field) => (
                    <div key={field.name}>
                      <span className="block text-xs font-semibold text-slate-400 mb-1.5">{field.label}</span>
                      <div className="relative">
                        <input
                          type="number"
                          name={field.name}
                          value={(profile.dailyGoals as any)[field.name]}
                          onChange={handleGoalChange}
                          className="w-full pl-3 pr-8 py-2 rounded-lg border border-slate-200 bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all text-sm font-medium text-slate-700 shadow-sm"
                        />
                        <span className="absolute right-2 top-2 text-[10px] text-slate-400 font-medium">{field.unit}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  Available Ingredients (Optional)
                </label>
                <textarea
                  name="availableIngredients"
                  placeholder="What's in your kitchen? (e.g., Spinach, Chicken, Rice)"
                  rows={2}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-white text-slate-800 placeholder:text-slate-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all resize-none shadow-sm"
                  value={profile.availableIngredients}
                  onChange={handleChange}
                />
              </div>
            </div>
          </div>

          <div className="pt-4">
            <button
              type="submit"
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-4 px-6 rounded-xl transition-all flex items-center justify-center gap-3 shadow-lg shadow-slate-200 hover:shadow-xl transform hover:-translate-y-0.5"
            >
              <Shield className="h-5 w-5 text-emerald-400" />
              Generate Safety Analysis & Recipes
              <ArrowRight className="h-5 w-5" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};