import { GoogleGenAI, Type } from "@google/genai";
import { UserProfile, AnalysisResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeProfileAndGetRecipes = async (profile: UserProfile): Promise<AnalysisResult> => {
  const prompt = `
    You are NutriSafe, an AI-assisted medical nutrition decision system.
    
    This is a PROTOTYPE DEMONSTRATION.
    
    The user's primary goal is: **${profile.primaryGoal.toUpperCase().replace('-', ' ')}**
    
    The user has provided the following profile:
    - Medical Conditions: ${profile.conditions}
    - Diet Type: ${profile.diet}
    - Oil Preference: ${profile.oilLevel}
    - Allergies/Avoid: ${profile.allergies}
    - Nutrient Focus: ${profile.nutrientFocus}
    - Available Ingredients: ${profile.availableIngredients || "Standard kitchen staples"}
    - Daily Nutritional Goals:
       - Calories: ${profile.dailyGoals.calories} kcal
       - Protein: ${profile.dailyGoals.protein} g
       - Carbs: ${profile.dailyGoals.carbs} g
       - Fats: ${profile.dailyGoals.fats} g

    System Note: Simulate the retrieval and logic application of Foodoscope RecipeDB and FlavorDB using your internal knowledge base as a proxy for the live API response.

    Perform the following steps internally:
    1. **Medical & Diet Analysis**: Identify ingredients to strictly avoid and preferred ingredients based on medical safety. Be conservative. Consider the '${profile.oilLevel}' preference when selecting cooking methods or ingredients.
    2. **FlavorDB Simulation**: Act as "Foodoscope FlavorDB". Identify ingredients that are chemically compatible or good flavor substitutes for the preferred ingredients to expand the safe list.
    3. **RecipeDB Simulation**: Act as "Foodoscope RecipeDB". Select 3 medically safe recipes using the expanded safe ingredient list.
       - Ensure recipes respect all constraints.
       - IMPORTANT: The recipes should be suitable portions that help the user progress towards their daily goals without exceeding them in a single meal (e.g. a meal should be roughly 30-40% of daily intake).

    Return the result in the following JSON structure.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          analysis: {
            type: Type.OBJECT,
            properties: {
              avoid: { type: Type.ARRAY, items: { type: Type.STRING }, description: "List of ingredients to strictly avoid" },
              preferred: { type: Type.ARRAY, items: { type: Type.STRING }, description: "List of nutritionally preferred ingredients" },
              medicalReasoning: { type: Type.STRING, description: "Explanation of safety rules applied" }
            },
            required: ["avoid", "preferred", "medicalReasoning"]
          },
          flavorDB: {
            type: Type.OBJECT,
            properties: {
              suggestions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    base: { type: Type.STRING, description: "Original ingredient or category" },
                    suggestion: { type: Type.STRING, description: "FlavorDB suggested pairing or substitute" },
                    reason: { type: Type.STRING, description: "Chemical/Flavor compatibility reason" }
                  },
                  required: ["base", "suggestion", "reason"]
                }
              },
              expansionReasoning: { type: Type.STRING, description: "Summary of how FlavorDB expanded the list" }
            },
            required: ["suggestions", "expansionReasoning"]
          },
          recipes: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.INTEGER },
                name: { type: Type.STRING },
                keyIngredients: { type: Type.ARRAY, items: { type: Type.STRING } },
                primaryBenefit: { type: Type.STRING },
                details: {
                  type: Type.OBJECT,
                  properties: {
                    ingredients: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          name: { type: Type.STRING },
                          quantity: { type: Type.STRING }
                        },
                        required: ["name", "quantity"]
                      }
                    },
                    steps: { type: Type.ARRAY, items: { type: Type.STRING } },
                    nutrition: {
                      type: Type.OBJECT,
                      properties: {
                        calories: { type: Type.NUMBER },
                        protein: { type: Type.STRING },
                        carbs: { type: Type.STRING },
                        fats: { type: Type.STRING },
                        micros: { type: Type.STRING }
                      },
                      required: ["calories", "protein", "carbs", "fats", "micros"]
                    },
                    safetyReasoning: { type: Type.STRING }
                  },
                  required: ["ingredients", "steps", "nutrition", "safetyReasoning"]
                }
              },
              required: ["id", "name", "keyIngredients", "primaryBenefit", "details"]
            }
          }
        },
        required: ["analysis", "flavorDB", "recipes"]
      }
    }
  });

  const text = response.text;
  if (!text) {
    throw new Error("No response from AI");
  }

  return JSON.parse(text) as AnalysisResult;
};